﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrderAndInvoiceManagementSystem.Controllers
{
    public class ClerkController : Controller
    {
        // GET: Clerk
        public ActionResult Index()
        {
            ViewData["UserName"] = Session["User"].ToString();
            return View();
        }
    }
}