﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using OrderAndInvoiceManagementSystem.Models;

namespace OrderAndInvoiceManagementSystem.Controllers
{
    /// <summary>
    /// Aurthor : Shadab Siddiqui
    /// Purpose : Controllers for user Login
    /// Date : 29/10/2018
    /// </summary>
    public class LoginController : Controller
    {
        DBModel db = new DBModel();
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {
            Session.Abandon();
            return View();
        }

        [HttpPost]
        public ActionResult Login(User user)
        {
            try
             {

                if (ModelState.IsValid) //Check if modelStat is valid or not
                {
                    User existingUser = (from u in db.Users //LINQ to get user according to user name 
                                         where user.Username == u.Username
                                         select u).SingleOrDefault();
                    if (existingUser == null)

                    {
                        ViewData["Message"] = "User not found"; //Save error Message to viewData if user is not found 
                        return View(user);

                    }
                    else
                    {
                        if (user.Password == existingUser.Password)
                        {
                            if (user.Status == existingUser.Status)
                            {
                                if (user.Status.Equals("Admin"))
                                {
                                    Session["User"] = existingUser.Username.ToString(); //Create session 
                                    Response.Redirect("/Admin/Admin");//Redirect to Admin page
                                }
                                else if (user.Status.Equals("Clerk"))
                                {
                                    Session["User"] = existingUser.Username.ToString(); //Create session 
                                    Response.Redirect("/Clerk/Index"); //Redirect to Clerk page
                                }
                            }

                            else
                            {
                                ViewData["Message"] = "Invalid status";
                                return View(user);
                            }

                            return View();

                        }
                        else
                        {
                            ViewData["Message"] = "Invalid password";
                            return View(user);

                        }

                    }
                }
                else
                {
                    var query = from state in ModelState.Values //LINQ to get error messages from ModelState 
                                from error in state.Errors
                                select error.ErrorMessage;

                    ViewData["errorMsg"] = query.ToList(); //Save error messages to ViewData

                    return View(user);
                }

            }
            catch (Exception ex)
            {
                ViewData["errorMsg"] = new List<string>() { ex.Message, " " };
                return View(user);
            }
        }

    }
}