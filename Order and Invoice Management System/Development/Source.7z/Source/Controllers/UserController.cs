﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using OrderAndInvoiceManagementSystem.Models;


namespace OrderAndInvoiceManagementSystem.Controllers
{
    /// <summary>
    /// Aurthor : Shadab Siddiqui
    /// Purpose : Controllers for user Login
    /// Date : 29/10/2018
    /// </summary>   
    public class UserController : Controller
    {
        DBModel dbContext = new DBModel();//Creating dbcontext for OIMS
  
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult ShowAllUsers()
        {
            IEnumerable<User> users = dbContext.Users.ToList();//Get details of all the users
            return View(users);
        }

        [HttpGet]
        public ActionResult ShowDetails(int id)
        {
            User user = dbContext.Users.Single(u => u.ID == id); //Get detials of user by id
            return View(user);
        }

       
        [HttpGet]
        public ActionResult CreateNewUser()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateNewUser(User user)
        {
            try
            {
               
                if (ModelState.IsValid)
                {
                    dbContext.Users.Add(user); //Add new user to table 
                    dbContext.SaveChanges(); //Save changes 
                }

                else
                {
                    var query = from state in ModelState.Values
                                from error in state.Errors
                                select error.ErrorMessage;
                    
                    ViewData["errorMsg"] = query.ToList(); //Save error messages in view data

                    return View(user);
                }
                return RedirectToAction("ShowAllUsers"); //Rediret to show All users 
            }
            catch(Exception ex)
            {
                if (ex.InnerException.InnerException.Message.Contains("UNIQUE KEY constrain")) //Catch exception about Unique Key voilation
                    ViewData["errorMsg"] =new List<string>() {"User Name already exists."," " };
                else
                    ViewData["errorMsg"] = new List<string>() { ex.Message , " " };
                return View(user);
            }
        } 

        [HttpGet]
        public ActionResult EditUser(int id)
        {


            User user = new User();
            var result = (from u in dbContext.Users
                          where u.ID == id
                          select u).SingleOrDefault(); //LINQ to get user by id

            return View(result);
        }

        [HttpPost]
        public ActionResult EditUser(int id, FormCollection collection)
        {
            User user = dbContext.Users.Single(u => u.ID == id);
            try {
                if (ModelState == null) //Check if ModelState is null
                {
                    ViewData["errorMsg"] =new List<string>(){"ModelState is null"," " };
                    return View();
                }
                if (ModelState.IsValid ) //If Model is valid Update and save changes
                {
                user.ID =Convert.ToInt32(collection["ID"]);
                user.Password = collection["Password"];
                user.Status= collection["Status"];
                dbContext.SaveChanges();
                }

                else
                {
                    var query = from state in ModelState.Values //LINQ to get error messages from MOdelState
                                from error in state.Errors
                                select error.ErrorMessage;

                    ViewData["errorMsg"] = query.ToList(); //Save error messages to ViewData

                    return View();
                }

                return RedirectToAction("ShowAllUsers", user);
            }

            catch (DbEntityValidationException ex)
            {
                var query = from entityValidationErrors in ex.EntityValidationErrors   //LINQ query to get error messages for DbEntityException
                            from validationError in entityValidationErrors.ValidationErrors
                            select validationError.ErrorMessage;
                ViewData["errorMsg"] = query.ToList(); // Save error messages in ViewData 

                return View(user);
                
            }
            catch (Exception ex)
            {

                if (ex.InnerException.InnerException.Message.Contains("UNIQUE KEY constrain"))
                    ViewData["errorMsg"] = new List<string>() { "User Name already exists.", " " };
                else
                    ViewData["errorMsg"] = new List<string>() { ex.Message, " " };
                return View(user);
           
            }
        } 

        [HttpGet]
        public ActionResult DeleteUser(int id)
        {
            User user = dbContext.Users.Single(u => u.ID == id);
            return View(user);
        }

        
        [HttpPost]
        public ActionResult DeleteUser(int id, FormCollection collection)
        {
            try
            {
                User user = dbContext.Users.Single(u => u.ID == id); //Get user by id
                dbContext.Users.Remove(user); //Delete user 
                dbContext.SaveChanges(); //Save changes
                return RedirectToAction("ShowAllUsers"); 
            }
            catch
            {
                return View();
            }
        }
    }
}